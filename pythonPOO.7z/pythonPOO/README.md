# Python Projects

Random python projects I am currently working on...

![alt text](https://github.com/mateusbaleta/pythonPOO/blob/main/img/logo.png?raw=true)

## 🚀 Run

 ```
It might but it might not to
 ```
### 📋 Prerequisites

- Python


### 🔧 Installation
```
pip install -r requirements.txt
```

## 🛠️ Made with

- Python 3.9


⌨️ Made with ❤