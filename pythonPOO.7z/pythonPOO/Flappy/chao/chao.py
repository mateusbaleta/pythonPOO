
class Chao:
    pass