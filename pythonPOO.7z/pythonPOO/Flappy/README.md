# Python Projects

Python Flappy Bird

![alt text](https://github.com/mateusbaleta/pythonPOO/blob/main/Flappy/logo/logogit.jpg?raw=true)


## 🚀 Run

 ```
Comming soon...
 ```
### 📋 Prerequisites

- Python


### 🔧 Installation
```
pip install -r requirements.txt
```

## 🛠️ Made with

- Python 3.9


⌨️ Made with ❤